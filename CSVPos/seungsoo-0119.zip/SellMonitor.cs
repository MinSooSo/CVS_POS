﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSVPos
{
    public partial class SellMonitor : Form
    {
        private SqlConnection con;
        private DataTable products;
        private int proNum = 1;
        private int eaCount = 1;
        private bool newProduct = false;
        int allPrice = 0;
        string afterDC;
        FormDiscount fd;

        public SellMonitor()
        {
            InitializeComponent();
        }

        private void SellMonitor_Load(object sender, EventArgs e)
        {
            timeStart();
            label4.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            MakeTable();

        }

        private void MakeTable()
        {
            products = new DataTable();
            products.Columns.Add("NO");
            products.Columns.Add("상품명");
            products.Columns.Add("단가", typeof(int));
            products.Columns.Add("수량", typeof(int));
            products.Columns.Add("금액", typeof(double));
            products.Columns.Add("할인");

            dataGridView1.DataSource = products;
        }

        public void timeStart()
        {
            label2.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimer);
            timer.Start();
        }

        public void OnTimer(object sender, System.Timers.ElapsedEventArgs args)
        {
            Invoke((MethodInvoker)delegate
            {
                label2.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            });
        }

        private void btnGohome_Click(object sender, EventArgs e) // 직원 교대 테이블 
        {
            // 꺼졌다가 켜지는 부분 자연스럽게 가능한가염 아몰랑
          
            StaffNum sn = new StaffNum();
            sn.Formname = "sell";
            sn.Show();
            this.Close();
          
        }

        private void btnExit_Click(object sender, EventArgs e) // 판매 완료를 눌렀을 때
        {
            // datagidview랑 각종 textbox 지우세요. datasource 등등
            // DB에도 Insert 하세요 

            // 객층 선택 키 숨겨둠 ==> 카드 결제, 기프티콘 결제 이후에 작동 2018.01.16
            CustomerAgeSex cas = new CustomerAgeSex();
            cas.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e) // 종료 picture을 눌렀을 때 
        {
            if(MessageBox.Show("판매 관리창에서 바로 종료할 수 없습니다. \t\n 확인 버튼을 누르시면 메인화면으로 이동합니다.","판매 종료 확인", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)== DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnTakbae_Click(object sender, EventArgs e) // 택배 접수 버튼을 눌렀을 때
        {
            frmPost fp = new frmPost();
            fp.Show();
        }

        private void btnDiscount_Click(object sender, EventArgs e) // 할인 사용 여부를 눌렀을 때 
        {
            // 폼 사이의 데이터 이동을 위해 전역변수로 선언. 2018.01.19
            fd = new FormDiscount();

            fd.txtBeforeDC.Text = allPrice.ToString();
            fd.ShowDialog();

            txtPrice.Text = fd.SendPrice().ToString();
            txtDiscount.Text = fd.SendPercent().ToString();
        }

        private void btnCredit_Click(object sender, EventArgs e) // 카드 결제를 눌렀을 때
        {
            PayCredit pc = new PayCredit();
            pc.ShowDialog();
        }

        private void btnBill_Click(object sender, EventArgs e)// 영수증 발급을 눌렀을 때
        {
            FormBill fb = new FormBill();
            fb.Show();
        }

        private void btnGifti_Click(object sender, EventArgs e) // 기프티콘 결제 버튼을 눌렀을 때
        {
            FormGifti fg = new FormGifti();
            fg.ShowDialog();
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            // 화면 그리드뷰에 바코드 찍은 판매할 물건을 표시해주고
            // 이후에 할인, 기프티콘 결제 기능 작동하게 2018.01.18
            if (txtBarcode.Text.Length == 8 || txtBarcode.Text.Length == 13)
            {
                con = Connection.GetInstance();
                // 발주 테이블에서 맞는 바코드가 있으면 모든 정보를 출력해주는 저장프로시저
                using (SqlCommand cmd = new SqlCommand("ms_SelectStock", con))
                {
                    con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@barcode", txtBarcode.Text);


                    SqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        while (sdr.Read())
                        {
                            MakeRows(proNum, sdr["PS_productName"].ToString(), sdr["PS_sellPrice"].ToString());
                            //gifti = sdr["PS_event"].ToString(); // 기프티콘 여부 조회? (DB랑 비교 2018.01.19.01:32)
                        }
                    }
                }
                con.Close();
            }
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = products;

        }

        private void MakeRows(int proNum, string name, string price)
        {
            
            //MessageBox.Show(proNum + " , " + name + " , " + price + " , " + ea);
            if (products.Rows.Count == 0) // 바코드를 처음 찍을 때
            {
                eaCount = 1;
                MessageBox.Show("현재 바코드 없음");
                DataRow newRow = products.NewRow();
                products.Rows.Add(newRow);
                newRow["NO"] = proNum;
                newRow["상품명"] = name;
                newRow["단가"] = price;
                newRow["수량"] = eaCount;
                newRow["금액"] = int.Parse(price) * eaCount;
                newRow["할인"] = 0;

                txtProduct.Text = name;
                txtEA.Text = eaCount.ToString();
                allPrice = int.Parse(price);
                txtPrice.Text = allPrice.ToString();
            }
            else // 이미 찍힌 바코드가 있을 때
            {
                proNum++;
                MessageBox.Show("이미 찍힌 바코드가 있을 때");
                //foreach (DataRow row in products.Rows)
                //{
                //    MessageBox.Show(row["상품명"].ToString());
                //    if (row["상품명"].ToString() == name) // 기존 상품을 찍을 때 (수량, 금액 증가)
                //    {
                //        MessageBox.Show("기존 상품 추가 등록");
                //        // 접근하자 2018.01.18 20:34

                //        eaCount++; // 수량 증가를 위한 전역변수 값 증가

                //        row["수량"] = eaCount;
                //        row["금액"] = eaCount * int.Parse(price);
                //        continue;
                //    }
                //    else // 새로운 상품을 찍을 때
                //    {
                //        MessageBox.Show("새로운 상품 등록");
                //        eaCount = 1;
                //        MessageBox.Show("Test");
                //        MessageBox.Show(products.Rows.Count.ToString());
                //        DataRow newRow = products.NewRow();
                //        products.Rows.Add(newRow);
                //        newRow["NO"] = proNum;
                //        newRow["상품명"] = name;
                //        newRow["단가"] = price;
                //        newRow["수량"] = eaCount;
                //        newRow["금액"] = int.Parse(price) * eaCount;
                //        newRow["할인"] = 0;
                //        return;
                //    }
                //}
                //for (int i = 0; i < products.Rows.Count; i++) // 이전에 찍어놓은 상품 리스트 중
                //{
                foreach (DataRow row in products.Rows)
                {
                    //MessageBox.Show("행 추가하기 전 row : " + products.Rows.Count);
                    if (row["상품명"].ToString() != name) // 새로운 상품을 찍을 때
                    {
                        MessageBox.Show(row["상품명"].ToString() + "검사 : " + name + "에 대한 새로운 상품 등록 필요");
                        newProduct = true;
                    }
                    else // 기존 상품을 찍을 때 (수량, 금액이 증가)
                    {
                        newProduct = false;
                        MessageBox.Show(row["상품명"].ToString() + "검사 : 기존 상품 수량 증가");
                        // 접근하자 2018.01.18 20:34
                        eaCount = int.Parse(row["수량"].ToString()); // A 상품 찍고 B 상품의 수량을 늘릴 때 B 상품 기존 수량 가져오기
                        eaCount++;// 수량 증가를 위한 전역변수 값 증가
                        row["수량"] = eaCount;                  
                        row["금액"] = eaCount * int.Parse(price);

                        txtProduct.Text = name;
                        txtEA.Text = eaCount.ToString();
                        allPrice += (int)row["단가"];
                        txtPrice.Text = allPrice.ToString();
                        return;
                    }
                }
                    //MessageBox.Show("행 추가하기 전 row : " + products.Rows.Count);
                    //if (products.Rows[i].Table.Columns["상품명"].ToString() != name) // 새로운 상품을 찍을 때
                    //{
                    //    newProduct = true;
                    //}
                    //else // 기존 상품을 찍을 때 (수량, 금액이 증가)
                    //{
                    //    // 접근하자 2018.01.18 20:34

                    //    eaCount++; // 수량 증가를 위한 전역변수 값 증가

                    //    //products.Rows[]
                    //    //products.Rows[1].Field<DataColumn>("수량") = eaCount;
                    //    //row["금액"] = eaCount * int.Parse(price);
                    //    //return;
                    //}
                //}
                if (newProduct)
                {
                    MessageBox.Show("바코드가 이미 찍혀있고 새로운 상품을 등록시킬 때");
                    eaCount = 1;
                    //MessageBox.Show("Test");
                    //MessageBox.Show(products.Rows.Count.ToString());
                    DataRow newRow = products.NewRow();
                    products.Rows.Add(newRow);
                    newRow["NO"] = proNum;
                    newRow["상품명"] = name;
                    newRow["단가"] = price;
                    newRow["수량"] = eaCount;
                    newRow["금액"] = int.Parse(price) * eaCount;
                    newRow["할인"] = 0;

                    txtProduct.Text = name;
                    txtEA.Text = eaCount.ToString();
                    allPrice += int.Parse(price);
                    txtPrice.Text = allPrice.ToString();                    
                }
            }
        }

        private void txtBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void txtBarcode_Click(object sender, EventArgs e)
        {
            txtBarcode.Text = "";
            //txtProduct.Text = "";
            //txtTime.Text = "";
            //txtEA.Text = "";
            //txtPrice.Text = "";
        }
    }
}
